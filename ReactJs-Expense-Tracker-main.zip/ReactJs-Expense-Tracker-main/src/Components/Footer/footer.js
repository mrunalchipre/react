import React from 'react'
import "./footer.css"

function Footer() {
  return (
    <footer>Made by Rocky🔥</footer>
  )
}

export default Footer